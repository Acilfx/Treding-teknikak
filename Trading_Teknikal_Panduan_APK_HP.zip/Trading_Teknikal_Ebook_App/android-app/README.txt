PROYEK ANDROID — TRADING & TEKNIKAL

CARA BUILD APK DARI HP (GITHUB ACTIONS):
1. Ekstrak ZIP ini di HP.
2. Buat repository baru di github.com.
3. Upload ISI folder android-app ke root repository, bukan folder android-app-nya.
   Pastikan file settings.gradle, build.gradle, gradle.properties, folder app/, dan folder .github/ ikut ter-upload.
4. Buka tab Actions pada repository.
5. Pilih "Build Trading Teknikal APK" lalu tekan Run workflow.
6. Tunggu sampai workflow selesai dengan status hijau.
7. Buka hasil run, cari bagian Artifacts, lalu unduh Trading-Teknikal-debug-apk.
8. Ekstrak file artifact dan instal app-debug.apk di Android. Jika diminta, izinkan browser/file manager memasang aplikasi dari sumber ini.

Catatan: file APK belum dikompilasi di dalam ZIP. GitHub Actions akan membangunnya secara online.
