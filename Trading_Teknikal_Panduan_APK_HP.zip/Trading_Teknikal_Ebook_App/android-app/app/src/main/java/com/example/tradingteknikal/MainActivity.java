package com.example.tradingteknikal;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.view.ViewGroup;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  WebView web = new WebView(this);
  web.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  settings.setBuiltInZoomControls(true);
  settings.setDisplayZoomControls(false);
  web.setBackgroundColor(0xFFF4F6FA);
  setContentView(web);
  web.loadUrl("file:///android_asset/ebook/index.html");
 }
 @Override public void onBackPressed() { super.onBackPressed(); }
}
