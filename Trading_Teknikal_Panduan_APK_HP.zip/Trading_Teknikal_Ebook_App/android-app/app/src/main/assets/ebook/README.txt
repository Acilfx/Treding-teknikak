BUKA E-BOOK
Buka index.html menggunakan browser. Untuk penggunaan offline di Android, salin folder web ke hosting HTTPS atau buka secara lokal melalui aplikasi file manager yang mendukung HTML.
